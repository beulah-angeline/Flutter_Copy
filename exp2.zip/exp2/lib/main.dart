
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: Shop()));

class Shop extends StatelessWidget {
  final names = ['Shoes', 'Watch', 'Bag'];
  final images = ['shoes.jpg', 'watch.jpg', 'bag.jpg'];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('ShopEase')),
    body: LayoutBuilder(builder: (context, size) {
      int n = size.maxWidth < 600 ? 1 : size.maxWidth < 900 ? 2 : 4;

      return GridView.builder(
        itemCount: names.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: n,
          childAspectRatio: 0.8,
        ),
        itemBuilder: (context, i) => Card(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Image.asset('assets/${images[i]}', height: 80),
              Text(names[i]),
              ElevatedButton(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${names[i]} added!')),
                ),
                child: Text('Add to Cart'),
              ),
            ],
          ),
        ),
      );
    }),
  );
}
