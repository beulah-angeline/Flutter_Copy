
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: MyApp()));

class MyApp extends StatelessWidget {
  final names = ['Nature', 'Flowers', 'Beach', 'Mountains'];
  final images = ['nature.jpg', 'flower.jpg', 'beach.jpg', 'mountain.jpg'];

  Widget item(String name, String image) {
    return Card(
      child: Column(
        children: [
          Expanded(
            child: Image.asset('assets/$image', fit: BoxFit.cover,
              width: double.infinity),
          ),
          Text(name),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Photo Gallery')),
    body: GridView.count(
      crossAxisCount: 2,
      children: List.generate(
        names.length,
        (i) => item(names[i], images[i]),
      ),
    ),
  );
}
