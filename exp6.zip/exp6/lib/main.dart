
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: MyApp()));

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool show = false;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Student Profile')),
    body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedOpacity(
            opacity: show ? 1 : 0,
            duration: Duration(seconds: 2),
            child: Card(
              child: ListTile(
                title: Text('Name: Anu'),
                subtitle: Text(
                  'Register No: 12345\n'
                  'Department: AI & ML\n'
                  'Year: Third Year',
                ),
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () => setState(() => show = true),
            child: Text('Show Profile'),
          ),
          ElevatedButton(
            onPressed: () => setState(() => show = false),
            child: Text('Hide Profile'),
          ),
        ],
      ),
    ),
  );
}
