
import 'package:flutter/material.dart';
void main() => runApp(MaterialApp(home: MyApp()));

class MyApp extends StatefulWidget {
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final c = List.generate(5, (_) => TextEditingController());
  String msg = '';
  bool red = false;

  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Budget Calculator')),
    body: ListView(padding: EdgeInsets.all(20), children: [
      for (int i = 0; i < 5; i++)
        TextField(controller: c[i], keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText:
            ['Income', 'Rent', 'Food', 'Transport', 'Others'][i])),

      ElevatedButton(onPressed: () {
        final n = c.map((x) => double.tryParse(x.text)).toList();
        setState(() {
          red = n.any((x) => x == null || x < 0) || (n[0] ?? 0) <= 0;
          if (red) {
            msg = 'Invalid amounts!';
          } else {
            double b = n[0]! - n[1]! - n[2]! - n[3]! - n[4]!;
            red = b < 0;
            msg = '${red ? "Overspending!" : "Money remaining!"} ₹${b.toStringAsFixed(2)}';
          }
        });
      }, child: Text('Calculate Balance')),

      Text(msg, style: TextStyle(color: red ? Colors.red : Colors.green)),
    ]),
  );
}
