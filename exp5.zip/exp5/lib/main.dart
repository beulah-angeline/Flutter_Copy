
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(routes: {
  '/': (c) => MyApp(),
  '/result': (c) => Result(),
}));

class MyApp extends StatelessWidget {
  final c = List.generate(4, (_) => TextEditingController());
  final names = ['Name', 'Register No', 'Total Classes', 'Classes Attended'];

  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Student Attendance')),
    body: ListView(children: [
      for (int i = 0; i < 4; i++)
        TextField(controller: c[i],
          decoration: InputDecoration(labelText: names[i])),
      ElevatedButton(
        onPressed: () {
          int? t = int.tryParse(c[2].text), a = int.tryParse(c[3].text);
          if (c[0].text.isEmpty || c[1].text.isEmpty ||
              t == null || t <= 0 || a == null || a < 0 || a > t) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Enter valid details')));
            return;
          }
          Navigator.pushNamed(context, '/result',
            arguments: c.map((x) => x.text).toList());
        },
        child: Text('View Attendance'),
      ),
    ]),
  );
}

class Result extends StatelessWidget {
  Widget build(BuildContext context) {
    final d = ModalRoute.of(context)!.settings.arguments as List;
    double p = int.parse(d[3]) / int.parse(d[2]) * 100;

    return Scaffold(
      appBar: AppBar(title: Text('Attendance Result')),
      body: Column(children: [
        Card(child: ListTile(
          title: Text('Name: ${d[0]}'),
          subtitle: Text('Register No: ${d[1]}\nTotal: ${d[2]}\n'
              'Attended: ${d[3]}\nAttendance: ${p.toStringAsFixed(2)}%'),
        )),
        Text(p >= 75 ? 'Eligible for Examination' : 'Not Eligible for Examination',
          style: TextStyle(color: p >= 75 ? Colors.green : Colors.red)),
        ElevatedButton(onPressed: () => Navigator.pop(context),
          child: Text('Back')),
      ]),
    );
  }
}
